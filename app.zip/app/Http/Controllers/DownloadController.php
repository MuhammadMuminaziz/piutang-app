<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DownloadController extends Controller
{
    public function downloadFaktur(Request $request)
    {
        dd($request);
    }
}
