<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Faktur</title>
    <style>
        .table {
            border-collapse: collapse;
        }
        
        .table tr th{
            background: rgb(219, 219, 219);
            text-align: left;
            padding: 0 5px;
        }

        .table tr td{
            padding: 0 5px;
        }
    </style>
</head>
<body>
    <h3 style="text-align: center">LAPORAN PIUTANG</h3>
    <hr>
    <p>Tanggal Cetak <?php echo e(date('d F Y')); ?></p>
    <table width="100%" class="table">
        <tr>
            <th class="text-start">No</th>
            <th class="text-start">ID Customer</th>
            <th class="text-start">Nama Pelanggan</th>
            <th class="text-start">Alamat</th>
            <th class="text-start">Piutang</th>
        </tr>
        <?php $__currentLoopData = $piutangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $piutang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($piutang->id_customer); ?></td>
                <td><?php echo e($piutang->name); ?></td>
                <td><?php echo e($piutang->address); ?></td>
                <td><?php echo e(currency_IDR($piutang->bill)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>
</html><?php /**PATH C:\projects\piutang-app\resources\views/pdf/laporan.blade.php ENDPATH**/ ?>